package com.nishanth.springbootadminserver;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAdminServerApplicationTests {

	

}
